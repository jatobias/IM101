-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: multi_company
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `emp_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_no` varchar(10) NOT NULL,
  `first_name` varchar(60) NOT NULL,
  `last_name` varchar(60) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `hire_date` date NOT NULL,
  `job_title` varchar(80) DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT 0.00,
  `manager_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`emp_id`),
  UNIQUE KEY `emp_no` (`emp_no`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_lastname_firstname` (`last_name`,`first_name`),
  KEY `fk_employees_manager` (`manager_id`),
  CONSTRAINT `fk_employees_manager` FOREIGN KEY (`manager_id`) REFERENCES `employees` (`emp_id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,'E0001','Aileen','Dizon','aileen.dizon@example.com','09171234567','2016-05-02','CEO',200000.00,NULL,'2025-10-29 03:17:15','2025-10-29 03:17:15'),(2,'E0002','Marco','Reyes','marco.reyes@example.com','09171234568','2017-03-15','CFO',150000.00,1,'2025-10-29 03:17:15','2025-10-29 03:17:15'),(3,'E0003','Liza','Garcia','liza.garcia@example.com','09171234569','2018-07-22','CTO',150000.00,1,'2025-10-29 03:17:15','2025-10-29 03:17:15'),(4,'E0004','Ramon','Santos','ramon.santos@example.com','09171234570','2019-02-10','Head of Engineering',120000.00,3,'2025-10-29 03:17:15','2025-10-29 03:17:15'),(5,'E0005','Joy','Torres','joy.torres@example.com','09171234571','2020-01-05','Senior Engineer',80000.00,4,'2025-10-29 03:17:15','2025-10-29 03:17:15'),(6,'E0006','John','Lacson','john.lacson@example.com','09171234572','2021-06-30','Engineer',60000.00,4,'2025-10-29 03:17:15','2025-10-29 03:17:15'),(7,'E0007','Rosa','Mendoza','rosa.mendoza@example.com','09171234573','2019-08-01','Head of HR',110000.00,2,'2025-10-29 03:17:15','2025-10-29 03:17:15'),(8,'E0008','Peter','Cruz','peter.cruz@example.com','09171234574','2022-04-20','HR Specialist',45000.00,7,'2025-10-29 03:17:15','2025-10-29 03:17:15'),(9,'E0009','Anna','Lopez','anna.lopez@example.com','09171234575','2023-09-01','Marketing Lead',90000.00,1,'2025-10-29 03:17:15','2025-10-29 03:17:15'),(10,'E0010','Ben','Ibarra','ben.ibarra@example.com','09171234576','2024-02-11','Operations Manager',95000.00,1,'2025-10-29 03:17:15','2025-10-29 03:17:15');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-29 12:46:45
